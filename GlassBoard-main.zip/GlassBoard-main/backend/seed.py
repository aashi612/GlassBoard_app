import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from passlib.context import CryptContext
from datetime import datetime
import os
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

async def seed_database():
    """Seed the database with initial data"""
    
    # Clear existing data
    await db.users.delete_many({})
    await db.modules.delete_many({})
    await db.tasks.delete_many({})
    await db.handoffs.delete_many({})
    await db.files.delete_many({})
    await db.file_edits.delete_many({})
    await db.audit_logs.delete_many({})
    
    print("Cleared existing data...")
    
    # Create Admin User
    admin_id = await db.users.insert_one({
        "email": "admin@glassboard.com",
        "password_hash": pwd_context.hash("admin123"),
        "name": "Admin User",
        "role": "admin",
        "module_id": None,
        "expo_push_token": None,
        "created_at": datetime.utcnow()
    })
    
    print(f"Created admin user: admin@glassboard.com / admin123")
    
    # Create Modules
    modules = [
        {
            "name": "Design",
            "description": "UI/UX Design Team",
            "color": "#4A90E2",
            "is_active": True,
            "created_at": datetime.utcnow()
        },
        {
            "name": "Development",
            "description": "Engineering Team",
            "color": "#66BB6A",
            "is_active": True,
            "created_at": datetime.utcnow()
        },
        {
            "name": "QA",
            "description": "Quality Assurance Team",
            "color": "#FFA726",
            "is_active": True,
            "created_at": datetime.utcnow()
        }
    ]
    
    module_ids = []
    for module in modules:
        result = await db.modules.insert_one(module)
        module_ids.append(result.inserted_id)
        print(f"Created module: {module['name']}")
        
        # Create audit log
        await db.audit_logs.insert_one({
            "action_type": "module_created",
            "user_id": str(admin_id.inserted_id),
            "user_name": "Admin User",
            "module_id": str(result.inserted_id),
            "module_name": module["name"],
            "details": f"Module '{module['name']}' created during seed",
            "timestamp": datetime.utcnow()
        })
    
    # Create Module Users
    module_users = [
        {
            "email": "design@glassboard.com",
            "password": "design123",
            "name": "Design Lead",
            "module_id": str(module_ids[0])
        },
        {
            "email": "dev@glassboard.com",
            "password": "dev123",
            "name": "Dev Lead",
            "module_id": str(module_ids[1])
        },
        {
            "email": "qa@glassboard.com",
            "password": "qa123",
            "name": "QA Lead",
            "module_id": str(module_ids[2])
        }
    ]
    
    user_ids = []
    for user_data in module_users:
        module = await db.modules.find_one({"_id": module_ids[module_users.index(user_data)]})
        user_id = await db.users.insert_one({
            "email": user_data["email"],
            "password_hash": pwd_context.hash(user_data["password"]),
            "name": user_data["name"],
            "role": "module_user",
            "module_id": user_data["module_id"],
            "expo_push_token": None,
            "created_at": datetime.utcnow()
        })
        user_ids.append(user_id.inserted_id)
        print(f"Created user: {user_data['email']} / {user_data['password']} for module {module['name']}")
        
        # Create audit log
        await db.audit_logs.insert_one({
            "action_type": "user_registered",
            "user_id": str(user_id.inserted_id),
            "user_name": user_data["name"],
            "module_id": user_data["module_id"],
            "module_name": module["name"],
            "details": f"User {user_data['name']} registered during seed",
            "timestamp": datetime.utcnow()
        })
    
    # Create Sample Tasks for Design Module
    design_tasks = [
        {"title": "Create wireframes", "description": "Design initial wireframes for dashboard"},
        {"title": "Design mockups", "description": "Create high-fidelity mockups"},
        {"title": "Review with stakeholders", "description": "Present designs to team"}
    ]
    
    for idx, task in enumerate(design_tasks):
        await db.tasks.insert_one({
            "module_id": str(module_ids[0]),
            "title": task["title"],
            "description": task["description"],
            "is_completed": False,
            "created_by": str(user_ids[0]),
            "created_at": datetime.utcnow(),
            "order": idx
        })
        print(f"Created task: {task['title']} for Design module")
    
    print("\n=== Database seeded successfully! ===\n")
    print("Login Credentials:")
    print("------------------")
    print("Admin: admin@glassboard.com / admin123")
    print("Design: design@glassboard.com / design123")
    print("Development: dev@glassboard.com / dev123")
    print("QA: qa@glassboard.com / qa123")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(seed_database())
