from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime, timedelta
from passlib.context import CryptContext
import jwt
from bson import ObjectId
import base64


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Configuration
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_DAYS = 30

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# Helper Functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=ACCESS_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    
    user["id"] = str(user["_id"])
    return user

async def get_admin_user(current_user: dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

# Models
class UserRegister(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: str = "module_user"  # admin or module_user
    module_id: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class ModuleCreate(BaseModel):
    name: str
    description: str
    color: str = "#4A90E2"

class ModuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = None
    is_active: Optional[bool] = None

class TaskCreate(BaseModel):
    module_id: str
    title: str
    description: Optional[str] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    is_completed: Optional[bool] = None

class HandoffCreate(BaseModel):
    from_module_id: str
    to_module_id: str
    proof_text: str
    proof_document_base64: Optional[str] = None
    proof_document_name: Optional[str] = None
    proof_document_type: Optional[str] = None

class HandoffResponse(BaseModel):
    response_text: Optional[str] = None

class FileUpload(BaseModel):
    name: str
    content_base64: str
    file_type: str
    size_bytes: int
    module_id: str

class FileEdit(BaseModel):
    content_base64: str
    edit_description: str

class PushTokenUpdate(BaseModel):
    expo_push_token: str

# Auth Routes
@api_router.post("/auth/register")
async def register(user: UserRegister):
    # Check if user exists
    existing_user = await db.users.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Validate module_id if role is module_user
    if user.role == "module_user":
        if not user.module_id:
            raise HTTPException(status_code=400, detail="Module ID required for module users")
        module = await db.modules.find_one({"_id": ObjectId(user.module_id)})
        if not module:
            raise HTTPException(status_code=400, detail="Module not found")
    
    # Create user
    user_dict = {
        "email": user.email,
        "password_hash": get_password_hash(user.password),
        "name": user.name,
        "role": user.role,
        "module_id": user.module_id,
        "expo_push_token": None,
        "created_at": datetime.utcnow()
    }
    
    result = await db.users.insert_one(user_dict)
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "user_registered",
        "user_id": str(result.inserted_id),
        "user_name": user.name,
        "module_id": user.module_id,
        "module_name": None,
        "details": f"User {user.name} registered with role {user.role}",
        "timestamp": datetime.utcnow()
    })
    
    # Create token
    access_token = create_access_token(data={"sub": str(result.inserted_id)})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": str(result.inserted_id),
            "email": user.email,
            "name": user.name,
            "role": user.role,
            "module_id": user.module_id
        }
    }

@api_router.post("/auth/login")
async def login(user: UserLogin):
    db_user = await db.users.find_one({"email": user.email})
    if not db_user or not verify_password(user.password, db_user["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    
    # Get module name if user is module_user
    module_name = None
    if db_user.get("module_id"):
        module = await db.modules.find_one({"_id": ObjectId(db_user["module_id"])})
        if module:
            module_name = module["name"]
    
    access_token = create_access_token(data={"sub": str(db_user["_id"])})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": str(db_user["_id"]),
            "email": db_user["email"],
            "name": db_user["name"],
            "role": db_user["role"],
            "module_id": db_user.get("module_id"),
            "module_name": module_name
        }
    }

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    # Get module name if user is module_user
    module_name = None
    if current_user.get("module_id"):
        module = await db.modules.find_one({"_id": ObjectId(current_user["module_id"])})
        if module:
            module_name = module["name"]
    
    return {
        "id": current_user["id"],
        "email": current_user["email"],
        "name": current_user["name"],
        "role": current_user["role"],
        "module_id": current_user.get("module_id"),
        "module_name": module_name,
        "expo_push_token": current_user.get("expo_push_token")
    }

@api_router.put("/auth/push-token")
async def update_push_token(token_data: PushTokenUpdate, current_user: dict = Depends(get_current_user)):
    await db.users.update_one(
        {"_id": ObjectId(current_user["id"])},
        {"$set": {"expo_push_token": token_data.expo_push_token}}
    )
    return {"message": "Push token updated successfully"}

# Module Routes
@api_router.get("/modules")
async def get_modules(current_user: dict = Depends(get_current_user)):
    modules = await db.modules.find({"is_active": True}).to_list(1000)
    result = []
    for module in modules:
        module_dict = {
            "id": str(module["_id"]),
            "name": module["name"],
            "description": module["description"],
            "color": module["color"],
            "is_active": module["is_active"],
            "created_at": module["created_at"].isoformat()
        }
        
        # Calculate progress
        total_tasks = await db.tasks.count_documents({"module_id": str(module["_id"])})
        completed_tasks = await db.tasks.count_documents({"module_id": str(module["_id"]), "is_completed": True})
        module_dict["progress"] = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        module_dict["total_tasks"] = total_tasks
        module_dict["completed_tasks"] = completed_tasks
        
        result.append(module_dict)
    
    return result

@api_router.post("/modules")
async def create_module(module: ModuleCreate, current_user: dict = Depends(get_admin_user)):
    module_dict = {
        "name": module.name,
        "description": module.description,
        "color": module.color,
        "is_active": True,
        "created_at": datetime.utcnow()
    }
    
    result = await db.modules.insert_one(module_dict)
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "module_created",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": str(result.inserted_id),
        "module_name": module.name,
        "details": f"Module '{module.name}' created",
        "timestamp": datetime.utcnow()
    })
    
    return {
        "id": str(result.inserted_id),
        "name": module.name,
        "description": module.description,
        "color": module.color,
        "is_active": True,
        "created_at": module_dict["created_at"].isoformat()
    }

@api_router.put("/modules/{module_id}")
async def update_module(module_id: str, module_update: ModuleUpdate, current_user: dict = Depends(get_admin_user)):
    update_dict = {k: v for k, v in module_update.dict().items() if v is not None}
    
    if not update_dict:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    result = await db.modules.update_one(
        {"_id": ObjectId(module_id)},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Module not found")
    
    module = await db.modules.find_one({"_id": ObjectId(module_id)})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "module_updated",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": module_id,
        "module_name": module["name"],
        "details": f"Module '{module['name']}' updated",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Module updated successfully"}

@api_router.delete("/modules/{module_id}")
async def delete_module(module_id: str, current_user: dict = Depends(get_admin_user)):
    module = await db.modules.find_one({"_id": ObjectId(module_id)})
    if not module:
        raise HTTPException(status_code=404, detail="Module not found")
    
    # Soft delete - mark as inactive
    await db.modules.update_one(
        {"_id": ObjectId(module_id)},
        {"$set": {"is_active": False}}
    )
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "module_deleted",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": module_id,
        "module_name": module["name"],
        "details": f"Module '{module['name']}' deleted",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Module deleted successfully"}

# Task Routes
@api_router.get("/tasks")
async def get_tasks(module_id: str, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    tasks = await db.tasks.find({"module_id": module_id}).sort("order", 1).to_list(1000)
    return [
        {
            "id": str(task["_id"]),
            "module_id": task["module_id"],
            "title": task["title"],
            "description": task.get("description", ""),
            "is_completed": task["is_completed"],
            "created_by": task["created_by"],
            "created_at": task["created_at"].isoformat(),
            "order": task["order"]
        }
        for task in tasks
    ]

@api_router.post("/tasks")
async def create_task(task: TaskCreate, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != task.module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    # Get next order number
    existing_tasks = await db.tasks.find({"module_id": task.module_id}).to_list(1000)
    next_order = len(existing_tasks)
    
    task_dict = {
        "module_id": task.module_id,
        "title": task.title,
        "description": task.description or "",
        "is_completed": False,
        "created_by": current_user["id"],
        "created_at": datetime.utcnow(),
        "order": next_order
    }
    
    result = await db.tasks.insert_one(task_dict)
    
    # Get module name
    module = await db.modules.find_one({"_id": ObjectId(task.module_id)})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "task_created",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": task.module_id,
        "module_name": module["name"] if module else None,
        "details": f"Task '{task.title}' created",
        "timestamp": datetime.utcnow()
    })
    
    return {
        "id": str(result.inserted_id),
        "module_id": task.module_id,
        "title": task.title,
        "description": task.description or "",
        "is_completed": False,
        "created_by": current_user["id"],
        "created_at": task_dict["created_at"].isoformat(),
        "order": next_order
    }

@api_router.put("/tasks/{task_id}")
async def update_task(task_id: str, task_update: TaskUpdate, current_user: dict = Depends(get_current_user)):
    task = await db.tasks.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != task["module_id"]:
        raise HTTPException(status_code=403, detail="Access denied to this task")
    
    update_dict = {k: v for k, v in task_update.dict().items() if v is not None}
    
    if not update_dict:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    await db.tasks.update_one(
        {"_id": ObjectId(task_id)},
        {"$set": update_dict}
    )
    
    # Get module name
    module = await db.modules.find_one({"_id": ObjectId(task["module_id"])})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "task_updated",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": task["module_id"],
        "module_name": module["name"] if module else None,
        "details": f"Task '{task['title']}' updated",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Task updated successfully"}

@api_router.delete("/tasks/{task_id}")
async def delete_task(task_id: str, current_user: dict = Depends(get_current_user)):
    task = await db.tasks.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != task["module_id"]:
        raise HTTPException(status_code=403, detail="Access denied to this task")
    
    await db.tasks.delete_one({"_id": ObjectId(task_id)})
    
    # Get module name
    module = await db.modules.find_one({"_id": ObjectId(task["module_id"])})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "task_deleted",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": task["module_id"],
        "module_name": module["name"] if module else None,
        "details": f"Task '{task['title']}' deleted",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Task deleted successfully"}

@api_router.get("/tasks/progress/{module_id}")
async def get_task_progress(module_id: str, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    total_tasks = await db.tasks.count_documents({"module_id": module_id})
    completed_tasks = await db.tasks.count_documents({"module_id": module_id, "is_completed": True})
    
    progress = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
    all_completed = total_tasks > 0 and completed_tasks == total_tasks
    
    return {
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "progress": progress,
        "all_completed": all_completed
    }

# Handoff Routes
@api_router.post("/handoffs")
async def create_handoff(handoff: HandoffCreate, current_user: dict = Depends(get_current_user)):
    # Verify access - user must be from the source module
    if current_user["role"] == "module_user" and current_user.get("module_id") != handoff.from_module_id:
        raise HTTPException(status_code=403, detail="Can only create handoffs from your own module")
    
    # Verify all tasks are completed
    total_tasks = await db.tasks.count_documents({"module_id": handoff.from_module_id})
    completed_tasks = await db.tasks.count_documents({"module_id": handoff.from_module_id, "is_completed": True})
    
    if total_tasks == 0 or completed_tasks < total_tasks:
        raise HTTPException(status_code=400, detail="All tasks must be completed before creating a handoff")
    
    # Get module names
    from_module = await db.modules.find_one({"_id": ObjectId(handoff.from_module_id)})
    to_module = await db.modules.find_one({"_id": ObjectId(handoff.to_module_id)})
    
    if not from_module or not to_module:
        raise HTTPException(status_code=404, detail="Module not found")
    
    # Validate file if provided
    if handoff.proof_document_base64:
        # Validate file type
        allowed_types = [".pdf", ".jpeg", ".jpg", ".png", ".txt"]
        if not any(handoff.proof_document_name.lower().endswith(ext) for ext in allowed_types):
            raise HTTPException(status_code=400, detail="Invalid file type. Allowed: .pdf, .jpeg, .png, .txt")
        
        # Validate file size (4MB = 4 * 1024 * 1024 bytes)
        # Base64 increases size by ~33%, so we check the base64 length
        max_base64_size = int(4 * 1024 * 1024 * 1.37)  # ~5.5MB base64 for 4MB file
        if len(handoff.proof_document_base64) > max_base64_size:
            raise HTTPException(status_code=400, detail="File size exceeds 4MB limit")
    
    handoff_dict = {
        "from_module_id": handoff.from_module_id,
        "to_module_id": handoff.to_module_id,
        "from_module_name": from_module["name"],
        "to_module_name": to_module["name"],
        "status": "pending",
        "proof_text": handoff.proof_text,
        "proof_document_base64": handoff.proof_document_base64,
        "proof_document_name": handoff.proof_document_name,
        "proof_document_type": handoff.proof_document_type,
        "submitted_at": datetime.utcnow(),
        "responded_at": None,
        "submitted_by_id": current_user["id"],
        "submitted_by_name": current_user["name"],
        "responded_by_id": None,
        "responded_by_name": None,
        "response_text": None
    }
    
    result = await db.handoffs.insert_one(handoff_dict)
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "handoff_created",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": handoff.from_module_id,
        "module_name": from_module["name"],
        "details": f"Handoff created from {from_module['name']} to {to_module['name']}",
        "timestamp": datetime.utcnow()
    })
    
    # TODO: Send push notification to target module users
    # Get users from target module
    target_users = await db.users.find({"module_id": handoff.to_module_id, "expo_push_token": {"$ne": None}}).to_list(100)
    
    return {
        "id": str(result.inserted_id),
        "message": "Handoff created successfully",
        "status": "pending"
    }

@api_router.get("/handoffs/sent")
async def get_sent_handoffs(module_id: str, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    handoffs = await db.handoffs.find({"from_module_id": module_id}).sort("submitted_at", -1).to_list(1000)
    return [
        {
            "id": str(handoff["_id"]),
            "from_module_id": handoff["from_module_id"],
            "to_module_id": handoff["to_module_id"],
            "from_module_name": handoff["from_module_name"],
            "to_module_name": handoff["to_module_name"],
            "status": handoff["status"],
            "proof_text": handoff["proof_text"],
            "proof_document_name": handoff.get("proof_document_name"),
            "submitted_at": handoff["submitted_at"].isoformat(),
            "responded_at": handoff["responded_at"].isoformat() if handoff["responded_at"] else None,
            "submitted_by_name": handoff["submitted_by_name"],
            "responded_by_name": handoff.get("responded_by_name"),
            "response_text": handoff.get("response_text")
        }
        for handoff in handoffs
    ]

@api_router.get("/handoffs/received")
async def get_received_handoffs(module_id: str, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    handoffs = await db.handoffs.find({"to_module_id": module_id}).sort("submitted_at", -1).to_list(1000)
    return [
        {
            "id": str(handoff["_id"]),
            "from_module_id": handoff["from_module_id"],
            "to_module_id": handoff["to_module_id"],
            "from_module_name": handoff["from_module_name"],
            "to_module_name": handoff["to_module_name"],
            "status": handoff["status"],
            "proof_text": handoff["proof_text"],
            "proof_document_base64": handoff.get("proof_document_base64"),
            "proof_document_name": handoff.get("proof_document_name"),
            "proof_document_type": handoff.get("proof_document_type"),
            "submitted_at": handoff["submitted_at"].isoformat(),
            "responded_at": handoff["responded_at"].isoformat() if handoff["responded_at"] else None,
            "submitted_by_name": handoff["submitted_by_name"],
            "responded_by_name": handoff.get("responded_by_name"),
            "response_text": handoff.get("response_text")
        }
        for handoff in handoffs
    ]

@api_router.get("/handoffs/all")
async def get_all_handoffs(current_user: dict = Depends(get_admin_user)):
    handoffs = await db.handoffs.find().sort("submitted_at", -1).to_list(1000)
    return [
        {
            "id": str(handoff["_id"]),
            "from_module_id": handoff["from_module_id"],
            "to_module_id": handoff["to_module_id"],
            "from_module_name": handoff["from_module_name"],
            "to_module_name": handoff["to_module_name"],
            "status": handoff["status"],
            "proof_text": handoff["proof_text"],
            "submitted_at": handoff["submitted_at"].isoformat(),
            "responded_at": handoff["responded_at"].isoformat() if handoff["responded_at"] else None,
            "submitted_by_name": handoff["submitted_by_name"],
            "responded_by_name": handoff.get("responded_by_name")
        }
        for handoff in handoffs
    ]

@api_router.put("/handoffs/{handoff_id}/accept")
async def accept_handoff(handoff_id: str, response: HandoffResponse, current_user: dict = Depends(get_current_user)):
    handoff = await db.handoffs.find_one({"_id": ObjectId(handoff_id)})
    if not handoff:
        raise HTTPException(status_code=404, detail="Handoff not found")
    
    # Verify access - user must be from the target module
    if current_user["role"] == "module_user" and current_user.get("module_id") != handoff["to_module_id"]:
        raise HTTPException(status_code=403, detail="Can only respond to handoffs for your own module")
    
    if handoff["status"] != "pending":
        raise HTTPException(status_code=400, detail="Handoff already responded to")
    
    await db.handoffs.update_one(
        {"_id": ObjectId(handoff_id)},
        {"$set": {
            "status": "accepted",
            "responded_at": datetime.utcnow(),
            "responded_by_id": current_user["id"],
            "responded_by_name": current_user["name"],
            "response_text": response.response_text
        }}
    )
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "handoff_accepted",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": handoff["to_module_id"],
        "module_name": handoff["to_module_name"],
        "details": f"Handoff from {handoff['from_module_name']} accepted",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Handoff accepted successfully"}

@api_router.put("/handoffs/{handoff_id}/reject")
async def reject_handoff(handoff_id: str, response: HandoffResponse, current_user: dict = Depends(get_current_user)):
    handoff = await db.handoffs.find_one({"_id": ObjectId(handoff_id)})
    if not handoff:
        raise HTTPException(status_code=404, detail="Handoff not found")
    
    # Verify access - user must be from the target module
    if current_user["role"] == "module_user" and current_user.get("module_id") != handoff["to_module_id"]:
        raise HTTPException(status_code=403, detail="Can only respond to handoffs for your own module")
    
    if handoff["status"] != "pending":
        raise HTTPException(status_code=400, detail="Handoff already responded to")
    
    if not response.response_text:
        raise HTTPException(status_code=400, detail="Rejection reason is required")
    
    await db.handoffs.update_one(
        {"_id": ObjectId(handoff_id)},
        {"$set": {
            "status": "rejected",
            "responded_at": datetime.utcnow(),
            "responded_by_id": current_user["id"],
            "responded_by_name": current_user["name"],
            "response_text": response.response_text
        }}
    )
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "handoff_rejected",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": handoff["to_module_id"],
        "module_name": handoff["to_module_name"],
        "details": f"Handoff from {handoff['from_module_name']} rejected",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Handoff rejected successfully"}

# File Routes
@api_router.post("/files")
async def upload_file(file: FileUpload, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != file.module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    # Validate file type
    allowed_types = [".pdf", ".jpeg", ".jpg", ".png", ".txt"]
    if not any(file.name.lower().endswith(ext) for ext in allowed_types):
        raise HTTPException(status_code=400, detail="Invalid file type. Allowed: .pdf, .jpeg, .png, .txt")
    
    # Validate file size (4MB)
    if file.size_bytes > 4 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File size exceeds 4MB limit")
    
    file_dict = {
        "name": file.name,
        "content_base64": file.content_base64,
        "file_type": file.file_type,
        "size_bytes": file.size_bytes,
        "uploaded_by_id": current_user["id"],
        "uploaded_by_name": current_user["name"],
        "uploaded_at": datetime.utcnow(),
        "module_id": file.module_id,
        "current_version": 1,
        "parent_file_id": None
    }
    
    result = await db.files.insert_one(file_dict)
    
    # Create initial file edit entry
    await db.file_edits.insert_one({
        "file_id": str(result.inserted_id),
        "edited_by_id": current_user["id"],
        "edited_by_name": current_user["name"],
        "edit_description": "Initial upload",
        "timestamp": datetime.utcnow(),
        "changes_description": "File uploaded"
    })
    
    # Get module name
    module = await db.modules.find_one({"_id": ObjectId(file.module_id)})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "file_uploaded",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": file.module_id,
        "module_name": module["name"] if module else None,
        "details": f"File '{file.name}' uploaded",
        "timestamp": datetime.utcnow()
    })
    
    return {
        "id": str(result.inserted_id),
        "message": "File uploaded successfully"
    }

@api_router.get("/files")
async def get_files(module_id: str, current_user: dict = Depends(get_current_user)):
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != module_id:
        raise HTTPException(status_code=403, detail="Access denied to this module")
    
    files = await db.files.find({"module_id": module_id}).sort("uploaded_at", -1).to_list(1000)
    return [
        {
            "id": str(file["_id"]),
            "name": file["name"],
            "file_type": file["file_type"],
            "size_bytes": file["size_bytes"],
            "uploaded_by_name": file["uploaded_by_name"],
            "uploaded_at": file["uploaded_at"].isoformat(),
            "current_version": file["current_version"]
        }
        for file in files
    ]

@api_router.get("/files/{file_id}")
async def get_file(file_id: str, current_user: dict = Depends(get_current_user)):
    file = await db.files.find_one({"_id": ObjectId(file_id)})
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != file["module_id"]:
        raise HTTPException(status_code=403, detail="Access denied to this file")
    
    return {
        "id": str(file["_id"]),
        "name": file["name"],
        "content_base64": file["content_base64"],
        "file_type": file["file_type"],
        "size_bytes": file["size_bytes"],
        "uploaded_by_name": file["uploaded_by_name"],
        "uploaded_at": file["uploaded_at"].isoformat(),
        "current_version": file["current_version"]
    }

@api_router.put("/files/{file_id}")
async def edit_file(file_id: str, file_edit: FileEdit, current_user: dict = Depends(get_current_user)):
    file = await db.files.find_one({"_id": ObjectId(file_id)})
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != file["module_id"]:
        raise HTTPException(status_code=403, detail="Access denied to this file")
    
    # Update file
    new_version = file["current_version"] + 1
    await db.files.update_one(
        {"_id": ObjectId(file_id)},
        {"$set": {
            "content_base64": file_edit.content_base64,
            "current_version": new_version
        }}
    )
    
    # Create file edit entry
    await db.file_edits.insert_one({
        "file_id": file_id,
        "edited_by_id": current_user["id"],
        "edited_by_name": current_user["name"],
        "edit_description": file_edit.edit_description,
        "timestamp": datetime.utcnow(),
        "changes_description": f"Version {new_version}"
    })
    
    # Get module name
    module = await db.modules.find_one({"_id": ObjectId(file["module_id"])})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "file_edited",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": file["module_id"],
        "module_name": module["name"] if module else None,
        "details": f"File '{file['name']}' edited (v{new_version})",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "File updated successfully", "version": new_version}

@api_router.get("/files/{file_id}/history")
async def get_file_history(file_id: str, current_user: dict = Depends(get_current_user)):
    file = await db.files.find_one({"_id": ObjectId(file_id)})
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != file["module_id"]:
        raise HTTPException(status_code=403, detail="Access denied to this file")
    
    edits = await db.file_edits.find({"file_id": file_id}).sort("timestamp", -1).to_list(1000)
    return [
        {
            "edited_by_name": edit["edited_by_name"],
            "edit_description": edit["edit_description"],
            "timestamp": edit["timestamp"].isoformat(),
            "changes_description": edit["changes_description"]
        }
        for edit in edits
    ]

@api_router.delete("/files/{file_id}")
async def delete_file(file_id: str, current_user: dict = Depends(get_current_user)):
    file = await db.files.find_one({"_id": ObjectId(file_id)})
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Verify access
    if current_user["role"] == "module_user" and current_user.get("module_id") != file["module_id"]:
        raise HTTPException(status_code=403, detail="Access denied to this file")
    
    await db.files.delete_one({"_id": ObjectId(file_id)})
    await db.file_edits.delete_many({"file_id": file_id})
    
    # Get module name
    module = await db.modules.find_one({"_id": ObjectId(file["module_id"])})
    
    # Create audit log
    await db.audit_logs.insert_one({
        "action_type": "file_deleted",
        "user_id": current_user["id"],
        "user_name": current_user["name"],
        "module_id": file["module_id"],
        "module_name": module["name"] if module else None,
        "details": f"File '{file['name']}' deleted",
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "File deleted successfully"}

# Dashboard & Audit Routes
@api_router.get("/dashboard/overview")
async def get_dashboard_overview(current_user: dict = Depends(get_admin_user)):
    modules = await db.modules.find({"is_active": True}).to_list(1000)
    module_stats = []
    
    for module in modules:
        module_id = str(module["_id"])
        total_tasks = await db.tasks.count_documents({"module_id": module_id})
        completed_tasks = await db.tasks.count_documents({"module_id": module_id, "is_completed": True})
        progress = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        sent_handoffs = await db.handoffs.count_documents({"from_module_id": module_id})
        received_handoffs = await db.handoffs.count_documents({"to_module_id": module_id})
        pending_handoffs = await db.handoffs.count_documents({"to_module_id": module_id, "status": "pending"})
        
        module_stats.append({
            "id": module_id,
            "name": module["name"],
            "description": module["description"],
            "color": module["color"],
            "progress": progress,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "sent_handoffs": sent_handoffs,
            "received_handoffs": received_handoffs,
            "pending_handoffs": pending_handoffs
        })
    
    # Overall stats
    total_handoffs = await db.handoffs.count_documents({})
    total_pending = await db.handoffs.count_documents({"status": "pending"})
    total_accepted = await db.handoffs.count_documents({"status": "accepted"})
    total_rejected = await db.handoffs.count_documents({"status": "rejected"})
    total_files = await db.files.count_documents({})
    
    return {
        "modules": module_stats,
        "overall": {
            "total_modules": len(modules),
            "total_handoffs": total_handoffs,
            "pending_handoffs": total_pending,
            "accepted_handoffs": total_accepted,
            "rejected_handoffs": total_rejected,
            "total_files": total_files
        }
    }

@api_router.get("/audit-logs")
async def get_audit_logs(current_user: dict = Depends(get_admin_user), limit: int = 100):
    logs = await db.audit_logs.find().sort("timestamp", -1).limit(limit).to_list(limit)
    return [
        {
            "id": str(log["_id"]),
            "action_type": log["action_type"],
            "user_name": log["user_name"],
            "module_name": log.get("module_name"),
            "details": log["details"],
            "timestamp": log["timestamp"].isoformat()
        }
        for log in logs
    ]

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
