import apiClient from './client';

export interface FileItem {
  id: string;
  name: string;
  file_type: string;
  size_bytes: number;
  uploaded_by_name: string;
  uploaded_at: string;
  current_version: number;
  content_base64?: string;
}

export interface FileEdit {
  edited_by_name: string;
  edit_description: string;
  timestamp: string;
  changes_description: string;
}

export const filesAPI = {
  upload: async (data: {
    name: string;
    content_base64: string;
    file_type: string;
    size_bytes: number;
    module_id: string;
  }) => {
    const response = await apiClient.post('/files', data);
    return response.data;
  },

  getAll: async (moduleId: string): Promise<FileItem[]> => {
    const response = await apiClient.get(`/files?module_id=${moduleId}`);
    return response.data;
  },

  getById: async (id: string): Promise<FileItem> => {
    const response = await apiClient.get(`/files/${id}`);
    return response.data;
  },

  update: async (id: string, data: { content_base64: string; edit_description: string }) => {
    const response = await apiClient.put(`/files/${id}`, data);
    return response.data;
  },

  delete: async (id: string) => {
    const response = await apiClient.delete(`/files/${id}`);
    return response.data;
  },

  getHistory: async (id: string): Promise<FileEdit[]> => {
    const response = await apiClient.get(`/files/${id}/history`);
    return response.data;
  },
};