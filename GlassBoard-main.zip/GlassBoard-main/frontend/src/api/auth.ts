import apiClient from './client';
import { storage } from '../utils/storage';

export interface LoginData {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  name: string;
  role: string;
  module_id?: string;
}

export const authAPI = {
  login: async (data: LoginData) => {
    const response = await apiClient.post('/auth/login', data);
    const { access_token, user } = response.data;
    
    // Store auth data
    await storage.setItem('token', access_token);
    await storage.setItem('user', JSON.stringify(user));
    
    return { token: access_token, user };
  },

  register: async (data: RegisterData) => {
    const response = await apiClient.post('/auth/register', data);
    const { access_token, user } = response.data;
    
    // Store auth data
    await storage.setItem('token', access_token);
    await storage.setItem('user', JSON.stringify(user));
    
    return { token: access_token, user };
  },

  getMe: async () => {
    const response = await apiClient.get('/auth/me');
    return response.data;
  },

  updatePushToken: async (token: string) => {
    await apiClient.put('/auth/push-token', { expo_push_token: token });
  },
};