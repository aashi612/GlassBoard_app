import apiClient from './client';

export interface Module {
  id: string;
  name: string;
  description: string;
  color: string;
  is_active: boolean;
  created_at: string;
  progress?: number;
  total_tasks?: number;
  completed_tasks?: number;
}

export interface ModuleCreate {
  name: string;
  description: string;
  color: string;
}

export const modulesAPI = {
  getAll: async (): Promise<Module[]> => {
    const response = await apiClient.get('/modules');
    return response.data;
  },

  create: async (data: ModuleCreate): Promise<Module> => {
    const response = await apiClient.post('/modules', data);
    return response.data;
  },

  update: async (id: string, data: Partial<ModuleCreate>) => {
    const response = await apiClient.put(`/modules/${id}`, data);
    return response.data;
  },

  delete: async (id: string) => {
    const response = await apiClient.delete(`/modules/${id}`);
    return response.data;
  },
};