import apiClient from './client';

export interface Handoff {
  id: string;
  from_module_id: string;
  to_module_id: string;
  from_module_name: string;
  to_module_name: string;
  status: 'pending' | 'accepted' | 'rejected';
  proof_text: string;
  proof_document_base64?: string;
  proof_document_name?: string;
  proof_document_type?: string;
  submitted_at: string;
  responded_at?: string;
  submitted_by_name: string;
  responded_by_name?: string;
  response_text?: string;
}

export interface HandoffCreate {
  from_module_id: string;
  to_module_id: string;
  proof_text: string;
  proof_document_base64?: string;
  proof_document_name?: string;
  proof_document_type?: string;
}

export const handoffsAPI = {
  create: async (data: HandoffCreate) => {
    const response = await apiClient.post('/handoffs', data);
    return response.data;
  },

  getSent: async (moduleId: string): Promise<Handoff[]> => {
    const response = await apiClient.get(`/handoffs/sent?module_id=${moduleId}`);
    return response.data;
  },

  getReceived: async (moduleId: string): Promise<Handoff[]> => {
    const response = await apiClient.get(`/handoffs/received?module_id=${moduleId}`);
    return response.data;
  },

  getAll: async (): Promise<Handoff[]> => {
    const response = await apiClient.get('/handoffs/all');
    return response.data;
  },

  accept: async (id: string, responseText?: string) => {
    const response = await apiClient.put(`/handoffs/${id}/accept`, {
      response_text: responseText,
    });
    return response.data;
  },

  reject: async (id: string, responseText: string) => {
    const response = await apiClient.put(`/handoffs/${id}/reject`, {
      response_text: responseText,
    });
    return response.data;
  },
};