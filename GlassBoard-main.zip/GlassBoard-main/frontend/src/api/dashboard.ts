import apiClient from './client';

export interface DashboardOverview {
  modules: Array<{
    id: string;
    name: string;
    description: string;
    color: string;
    progress: number;
    total_tasks: number;
    completed_tasks: number;
    sent_handoffs: number;
    received_handoffs: number;
    pending_handoffs: number;
  }>;
  overall: {
    total_modules: number;
    total_handoffs: number;
    pending_handoffs: number;
    accepted_handoffs: number;
    rejected_handoffs: number;
    total_files: number;
  };
}

export interface AuditLog {
  id: string;
  action_type: string;
  user_name: string;
  module_name?: string;
  details: string;
  timestamp: string;
}

export const dashboardAPI = {
  getOverview: async (): Promise<DashboardOverview> => {
    const response = await apiClient.get('/dashboard/overview');
    return response.data;
  },

  getAuditLogs: async (limit: number = 100): Promise<AuditLog[]> => {
    const response = await apiClient.get(`/audit-logs?limit=${limit}`);
    return response.data;
  },
};