import apiClient from './client';

export interface Task {
  id: string;
  module_id: string;
  title: string;
  description: string;
  is_completed: boolean;
  created_by: string;
  created_at: string;
  order: number;
}

export interface TaskCreate {
  module_id: string;
  title: string;
  description?: string;
}

export interface TaskProgress {
  total_tasks: number;
  completed_tasks: number;
  progress: number;
  all_completed: boolean;
}

export const tasksAPI = {
  getAll: async (moduleId: string): Promise<Task[]> => {
    const response = await apiClient.get(`/tasks?module_id=${moduleId}`);
    return response.data;
  },

  create: async (data: TaskCreate): Promise<Task> => {
    const response = await apiClient.post('/tasks', data);
    return response.data;
  },

  update: async (id: string, data: Partial<Task>) => {
    const response = await apiClient.put(`/tasks/${id}`, data);
    return response.data;
  },

  delete: async (id: string) => {
    const response = await apiClient.delete(`/tasks/${id}`);
    return response.data;
  },

  getProgress: async (moduleId: string): Promise<TaskProgress> => {
    const response = await apiClient.get(`/tasks/progress/${moduleId}`);
    return response.data;
  },
};