import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { handoffsAPI, Handoff } from '../../../src/api/handoffs';
import { format } from 'date-fns';

export default function AdminHandoffsScreen() {
  const [handoffs, setHandoffs] = useState<Handoff[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchHandoffs = async () => {
    try {
      const data = await handoffsAPI.getAll();
      setHandoffs(data);
    } catch (error) {
      console.error('Failed to fetch handoffs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchHandoffs();
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchHandoffs();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return '#FFA726';
      case 'accepted':
        return '#66BB6A';
      case 'rejected':
        return '#E53935';
      default:
        return '#999';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return 'pending';
      case 'accepted':
        return 'check-circle';
      case 'rejected':
        return 'cancel';
      default:
        return 'help';
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {handoffs.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialIcons name="swap-horiz" size={64} color="#CCC" />
            <Text style={styles.emptyText}>No handoffs yet</Text>
          </View>
        ) : (
          handoffs.map((handoff) => (
            <View key={handoff.id} style={styles.handoffCard}>
              <View style={styles.handoffHeader}>
                <View style={styles.moduleFlow}>
                  <Text style={styles.moduleName}>{handoff.from_module_name}</Text>
                  <MaterialIcons name="arrow-forward" size={20} color="#666" style={styles.arrow} />
                  <Text style={styles.moduleName}>{handoff.to_module_name}</Text>
                </View>
                <View
                  style={[
                    styles.statusBadge,
                    { backgroundColor: getStatusColor(handoff.status) },
                  ]}
                >
                  <MaterialIcons
                    name={getStatusIcon(handoff.status)}
                    size={16}
                    color="#FFF"
                  />
                  <Text style={styles.statusText}>{handoff.status.toUpperCase()}</Text>
                </View>
              </View>

              <Text style={styles.proofLabel}>Proof:</Text>
              <Text style={styles.proofText}>{handoff.proof_text}</Text>

              <View style={styles.handoffFooter}>
                <View style={styles.userInfo}>
                  <MaterialIcons name="person" size={16} color="#666" />
                  <Text style={styles.userName}>{handoff.submitted_by_name}</Text>
                </View>
                <Text style={styles.timestamp}>
                  {format(new Date(handoff.submitted_at), 'MMM d, HH:mm')}
                </Text>
              </View>

              {handoff.responded_at && (
                <View style={styles.responseInfo}>
                  <Text style={styles.responseLabel}>
                    {handoff.status === 'accepted' ? 'Accepted' : 'Rejected'} by {handoff.responded_by_name}
                  </Text>
                  <Text style={styles.responseTime}>
                    {format(new Date(handoff.responded_at), 'MMM d, HH:mm')}
                  </Text>
                  {handoff.response_text && (
                    <Text style={styles.responseText}>{handoff.response_text}</Text>
                  )}
                </View>
              )}
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 16,
  },
  handoffCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  handoffHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  moduleFlow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  moduleName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  arrow: {
    marginHorizontal: 8,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#FFF',
    marginLeft: 4,
  },
  proofLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
    marginBottom: 4,
  },
  proofText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 12,
  },
  handoffFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userName: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  timestamp: {
    fontSize: 12,
    color: '#999',
  },
  responseInfo: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  responseLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
  },
  responseTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  responseText: {
    fontSize: 14,
    color: '#333',
    marginTop: 8,
    fontStyle: 'italic',
  },
});
