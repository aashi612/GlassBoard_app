import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { dashboardAPI, AuditLog } from '../../../src/api/dashboard';
import { format } from 'date-fns';

export default function AdminAuditScreen() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchLogs = async () => {
    try {
      const data = await dashboardAPI.getAuditLogs(200);
      setLogs(data);
    } catch (error) {
      console.error('Failed to fetch audit logs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchLogs();
  }, []);

  const getActionIcon = (action: string) => {
    if (action.includes('created')) return 'add-circle';
    if (action.includes('updated')) return 'edit';
    if (action.includes('deleted')) return 'delete';
    if (action.includes('accepted')) return 'check-circle';
    if (action.includes('rejected')) return 'cancel';
    if (action.includes('uploaded')) return 'cloud-upload';
    return 'info';
  };

  const getActionColor = (action: string) => {
    if (action.includes('created')) return '#66BB6A';
    if (action.includes('updated')) return '#4A90E2';
    if (action.includes('deleted')) return '#E53935';
    if (action.includes('accepted')) return '#66BB6A';
    if (action.includes('rejected')) return '#E53935';
    if (action.includes('uploaded')) return '#AB47BC';
    return '#999';
  };

  const renderItem = ({ item }: { item: AuditLog }) => (
    <View style={styles.logCard}>
      <View style={styles.logHeader}>
        <View
          style={[
            styles.iconContainer,
            { backgroundColor: getActionColor(item.action_type) + '20' },
          ]}
        >
          <MaterialIcons
            name={getActionIcon(item.action_type)}
            size={20}
            color={getActionColor(item.action_type)}
          />
        </View>
        <View style={styles.logContent}>
          <Text style={styles.logDetails}>{item.details}</Text>
          <View style={styles.logMeta}>
            <Text style={styles.logUser}>{item.user_name}</Text>
            {item.module_name && (
              <>
                <Text style={styles.separator}>•</Text>
                <Text style={styles.logModule}>{item.module_name}</Text>
              </>
            )}
          </View>
        </View>
      </View>
      <Text style={styles.logTime}>
        {format(new Date(item.timestamp), 'MMM d, yyyy HH:mm:ss')}
      </Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={logs}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <MaterialIcons name="history" size={64} color="#CCC" />
            <Text style={styles.emptyText}>No audit logs yet</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 16,
  },
  logCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  logHeader: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  logContent: {
    flex: 1,
  },
  logDetails: {
    fontSize: 14,
    color: '#333',
    marginBottom: 4,
  },
  logMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logUser: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  separator: {
    fontSize: 12,
    color: '#CCC',
    marginHorizontal: 6,
  },
  logModule: {
    fontSize: 12,
    color: '#4A90E2',
    fontWeight: '600',
  },
  logTime: {
    fontSize: 11,
    color: '#999',
    marginTop: 4,
  },
});
