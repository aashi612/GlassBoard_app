import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { dashboardAPI, DashboardOverview } from '../../../src/api/dashboard';
import { useAuthStore } from '../../../src/store/authStore';
import { CircularProgress } from 'react-native-circular-progress';

export default function AdminOverviewScreen() {
  const router = useRouter();
  const { logout } = useAuthStore();
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      const overview = await dashboardAPI.getOverview();
      setData(overview);
    } catch (error) {
      console.error('Failed to fetch overview:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchData();
  }, []);

  const handleLogout = async () => {
    await logout();
    router.replace('/login');
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Organization Overview</Text>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <MaterialIcons name="logout" size={24} color="#E53935" />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Overall Stats */}
        <View style={styles.statsCard}>
          <Text style={styles.sectionTitle}>Overall Statistics</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <MaterialIcons name="apps" size={32} color="#4A90E2" />
              <Text style={styles.statValue}>{data?.overall.total_modules || 0}</Text>
              <Text style={styles.statLabel}>Modules</Text>
            </View>
            <View style={styles.statItem}>
              <MaterialIcons name="swap-horiz" size={32} color="#66BB6A" />
              <Text style={styles.statValue}>{data?.overall.total_handoffs || 0}</Text>
              <Text style={styles.statLabel}>Handoffs</Text>
            </View>
            <View style={styles.statItem}>
              <MaterialIcons name="pending" size={32} color="#FFA726" />
              <Text style={styles.statValue}>{data?.overall.pending_handoffs || 0}</Text>
              <Text style={styles.statLabel}>Pending</Text>
            </View>
            <View style={styles.statItem}>
              <MaterialIcons name="folder" size={32} color="#AB47BC" />
              <Text style={styles.statValue}>{data?.overall.total_files || 0}</Text>
              <Text style={styles.statLabel}>Files</Text>
            </View>
          </View>
        </View>

        {/* Module Progress */}
        <Text style={styles.sectionTitle}>Module Progress</Text>
        {data?.modules.map((module) => (
          <View key={module.id} style={styles.moduleCard}>
            <View style={styles.moduleHeader}>
              <View style={styles.moduleInfo}>
                <View style={[styles.moduleColorDot, { backgroundColor: module.color }]} />
                <View>
                  <Text style={styles.moduleName}>{module.name}</Text>
                  <Text style={styles.moduleDescription}>{module.description}</Text>
                </View>
              </View>
              <CircularProgress
                size={60}
                width={6}
                fill={module.progress}
                tintColor={module.color}
                backgroundColor="#E0E0E0"
              >
                {() => <Text style={styles.progressText}>{Math.round(module.progress)}%</Text>}
              </CircularProgress>
            </View>

            <View style={styles.moduleStats}>
              <View style={styles.moduleStatItem}>
                <MaterialIcons name="checklist" size={20} color="#666" />
                <Text style={styles.moduleStatText}>
                  {module.completed_tasks}/{module.total_tasks} Tasks
                </Text>
              </View>
              <View style={styles.moduleStatItem}>
                <MaterialIcons name="pending" size={20} color="#FFA726" />
                <Text style={styles.moduleStatText}>
                  {module.pending_handoffs} Pending
                </Text>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  logoutButton: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  statsCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statItem: {
    width: '48%',
    alignItems: 'center',
    padding: 16,
    marginBottom: 16,
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  moduleCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  moduleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  moduleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  moduleColorDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  moduleName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  moduleDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  progressText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  moduleStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  moduleStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  moduleStatText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
});
