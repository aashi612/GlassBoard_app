import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Image,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { useAuthStore } from '../../../src/store/authStore';
import { filesAPI, FileItem, FileEdit } from '../../../src/api/files';
import { format } from 'date-fns';

export default function ModuleFilesScreen() {
  const { user } = useAuthStore();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);
  const [fileHistory, setFileHistory] = useState<FileEdit[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [viewModalVisible, setViewModalVisible] = useState(false);
  const [historyModalVisible, setHistoryModalVisible] = useState(false);

  const fetchFiles = async () => {
    if (!user?.module_id) return;

    try {
      const data = await filesAPI.getAll(user.module_id);
      setFiles(data);
    } catch (error) {
      console.error('Failed to fetch files:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, [user]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchFiles();
  }, [user]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please grant photo library access');
      return;
    }

    const result = await ImagePicker.launchImagePickerAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.8,
      base64: true,
    });

    if (!result.canceled && result.assets[0].base64 && user?.module_id) {
      const asset = result.assets[0];
      const fileName = asset.uri.split('/').pop() || 'image.jpg';
      const sizeBytes = asset.base64.length;

      if (sizeBytes > 4 * 1024 * 1024) {
        Alert.alert('Error', 'Image size exceeds 4MB limit');
        return;
      }

      try {
        await filesAPI.upload({
          name: fileName,
          content_base64: `data:image/jpeg;base64,${asset.base64}`,
          file_type: 'image/jpeg',
          size_bytes: sizeBytes,
          module_id: user.module_id,
        });
        Alert.alert('Success', 'Image uploaded successfully');
        fetchFiles();
      } catch (error: any) {
        Alert.alert('Error', error.response?.data?.detail || 'Failed to upload image');
      }
    }
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*', 'text/plain'],
        copyToCacheDirectory: true,
      });

      if (result.assets && result.assets[0] && user?.module_id) {
        const file = result.assets[0];
        
        if (file.size && file.size > 4 * 1024 * 1024) {
          Alert.alert('Error', 'File size exceeds 4MB limit');
          return;
        }

        // Read file as base64
        const response = await fetch(file.uri);
        const blob = await response.blob();
        const reader = new FileReader();
        
        reader.onloadend = async () => {
          const base64data = reader.result as string;
          
          try {
            await filesAPI.upload({
              name: file.name,
              content_base64: base64data,
              file_type: file.mimeType || 'application/octet-stream',
              size_bytes: file.size || 0,
              module_id: user.module_id!,
            });
            Alert.alert('Success', 'File uploaded successfully');
            fetchFiles();
          } catch (error: any) {
            Alert.alert('Error', error.response?.data?.detail || 'Failed to upload file');
          }
        };
        
        reader.readAsDataURL(blob);
      }
    } catch (error) {
      console.error('Document picker error:', error);
    }
  };

  const viewFile = async (file: FileItem) => {
    try {
      const fullFile = await filesAPI.getById(file.id);
      setSelectedFile(fullFile);
      setViewModalVisible(true);
    } catch (error) {
      Alert.alert('Error', 'Failed to load file');
    }
  };

  const viewHistory = async (file: FileItem) => {
    try {
      const history = await filesAPI.getHistory(file.id);
      setFileHistory(history);
      setSelectedFile(file);
      setHistoryModalVisible(true);
    } catch (error) {
      Alert.alert('Error', 'Failed to load file history');
    }
  };

  const deleteFile = (file: FileItem) => {
    Alert.alert('Delete File', `Delete "${file.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await filesAPI.delete(file.id);
            Alert.alert('Success', 'File deleted');
            fetchFiles();
          } catch (error) {
            Alert.alert('Error', 'Failed to delete file');
          }
        },
      },
    ]);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('image')) return 'image';
    if (fileType.includes('pdf')) return 'picture-as-pdf';
    if (fileType.includes('text')) return 'description';
    return 'insert-drive-file';
  };

  const renderFile = ({ item }: { item: FileItem }) => (
    <TouchableOpacity
      style={styles.fileCard}
      onPress={() => viewFile(item)}
      onLongPress={() => viewHistory(item)}
    >
      <View style={styles.fileIcon}>
        <MaterialIcons name={getFileIcon(item.file_type)} size={32} color="#4A90E2" />
      </View>
      <View style={styles.fileInfo}>
        <Text style={styles.fileName} numberOfLines={1}>
          {item.name}
        </Text>
        <Text style={styles.fileSize}>{formatFileSize(item.size_bytes)}</Text>
        <Text style={styles.fileUploadedBy}>
          {item.uploaded_by_name} • {format(new Date(item.uploaded_at), 'MMM d, HH:mm')}
        </Text>
        <Text style={styles.fileVersion}>v{item.current_version}</Text>
      </View>
      <TouchableOpacity onPress={() => deleteFile(item)} style={styles.deleteButton}>
        <MaterialIcons name="delete" size={20} color="#E53935" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={files}
        renderItem={renderFile}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <MaterialIcons name="folder-open" size={64} color="#CCC" />
            <Text style={styles.emptyText}>No files yet</Text>
            <Text style={styles.emptySubtext}>Tap + to upload a file</Text>
          </View>
        }
      />

      <View style={styles.fabContainer}>
        <TouchableOpacity style={[styles.fab, styles.fabSecondary]} onPress={pickDocument}>
          <MaterialIcons name="insert-drive-file" size={24} color="#FFF" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.fab} onPress={pickImage}>
          <MaterialIcons name="add-photo-alternate" size={28} color="#FFF" />
        </TouchableOpacity>
      </View>

      {/* View File Modal */}
      {selectedFile && (
        <Modal
          visible={viewModalVisible}
          animationType="slide"
          transparent
          onRequestClose={() => setViewModalVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle} numberOfLines={1}>
                  {selectedFile.name}
                </Text>
                <TouchableOpacity onPress={() => setViewModalVisible(false)}>
                  <MaterialIcons name="close" size={24} color="#666" />
                </TouchableOpacity>
              </View>

              {selectedFile.content_base64 &&
                selectedFile.file_type.includes('image') && (
                  <Image
                    source={{ uri: selectedFile.content_base64 }}
                    style={styles.filePreview}
                  />
                )}

              {selectedFile.file_type.includes('text') && (
                <Text style={styles.textPreview}>Text preview not available</Text>
              )}

              {selectedFile.file_type.includes('pdf') && (
                <View style={styles.pdfInfo}>
                  <MaterialIcons name="picture-as-pdf" size={48} color="#E53935" />
                  <Text style={styles.pdfText}>PDF Document</Text>
                </View>
              )}

              <View style={styles.fileDetails}>
                <Text style={styles.detailText}>
                  Size: {formatFileSize(selectedFile.size_bytes)}
                </Text>
                <Text style={styles.detailText}>
                  Version: {selectedFile.current_version}
                </Text>
                <Text style={styles.detailText}>
                  Uploaded by: {selectedFile.uploaded_by_name}
                </Text>
                <Text style={styles.detailText}>
                  Date: {format(new Date(selectedFile.uploaded_at), 'MMM d, yyyy HH:mm')}
                </Text>
              </View>

              <TouchableOpacity
                style={styles.historyButton}
                onPress={() => {
                  setViewModalVisible(false);
                  viewHistory(selectedFile);
                }}
              >
                <MaterialIcons name="history" size={20} color="#4A90E2" />
                <Text style={styles.historyButtonText}>View Edit History</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}

      {/* History Modal */}
      <Modal
        visible={historyModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setHistoryModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit History</Text>
              <TouchableOpacity onPress={() => setHistoryModalVisible(false)}>
                <MaterialIcons name="close" size={24} color="#666" />
              </TouchableOpacity>
            </View>

            <FlatList
              data={fileHistory}
              renderItem={({ item }) => (
                <View style={styles.historyItem}>
                  <View style={styles.historyIconContainer}>
                    <MaterialIcons name="edit" size={20} color="#4A90E2" />
                  </View>
                  <View style={styles.historyInfo}>
                    <Text style={styles.historyEditor}>{item.edited_by_name}</Text>
                    <Text style={styles.historyDescription}>{item.edit_description}</Text>
                    <Text style={styles.historyTime}>
                      {format(new Date(item.timestamp), 'MMM d, yyyy HH:mm:ss')}
                    </Text>
                  </View>
                </View>
              )}
              keyExtractor={(item, index) => index.toString()}
              ListEmptyComponent={
                <View style={styles.emptyHistory}>
                  <Text style={styles.emptyHistoryText}>No edit history</Text>
                </View>
              }
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#999',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#CCC',
    marginTop: 8,
  },
  fileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  fileIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E3F2FD',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  fileInfo: {
    flex: 1,
  },
  fileName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  fileSize: {
    fontSize: 12,
    color: '#999',
  },
  fileUploadedBy: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  fileVersion: {
    fontSize: 11,
    color: '#4A90E2',
    marginTop: 2,
  },
  deleteButton: {
    padding: 8,
  },
  fabContainer: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    alignItems: 'flex-end',
  },
  fab: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#4A90E2',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    marginTop: 12,
  },
  fabSecondary: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#66BB6A',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 500,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  filePreview: {
    width: '100%',
    height: 300,
    borderRadius: 8,
    marginBottom: 16,
    resizeMode: 'contain',
  },
  textPreview: {
    fontSize: 14,
    color: '#666',
    padding: 16,
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
    marginBottom: 16,
  },
  pdfInfo: {
    alignItems: 'center',
    padding: 32,
  },
  pdfText: {
    fontSize: 16,
    color: '#666',
    marginTop: 12,
  },
  fileDetails: {
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  historyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: '#4A90E2',
    borderRadius: 8,
  },
  historyButtonText: {
    fontSize: 14,
    color: '#4A90E2',
    marginLeft: 8,
    fontWeight: '600',
  },
  historyItem: {
    flexDirection: 'row',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  historyIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#E3F2FD',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  historyInfo: {
    flex: 1,
  },
  historyEditor: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  historyDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  historyTime: {
    fontSize: 11,
    color: '#999',
    marginTop: 4,
  },
  emptyHistory: {
    padding: 32,
    alignItems: 'center',
  },
  emptyHistoryText: {
    fontSize: 14,
    color: '#999',
  },
});
