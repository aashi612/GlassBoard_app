import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuthStore } from '../../../src/store/authStore';
import { tasksAPI, TaskProgress } from '../../../src/api/tasks';
import { handoffsAPI } from '../../../src/api/handoffs';
import { CircularProgress } from 'react-native-circular-progress';

export default function ModuleDashboardScreen() {
  const router = useRouter();
  const { user, logout } = useAuthStore();
  const [progress, setProgress] = useState<TaskProgress | null>(null);
  const [pendingHandoffs, setPendingHandoffs] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    if (!user?.module_id) return;

    try {
      const [progressData, receivedHandoffs] = await Promise.all([
        tasksAPI.getProgress(user.module_id),
        handoffsAPI.getReceived(user.module_id),
      ]);

      setProgress(progressData);
      setPendingHandoffs(receivedHandoffs.filter(h => h.status === 'pending').length);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchData();
  }, [user]);

  const handleLogout = async () => {
    await logout();
    router.replace('/login');
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>{user?.module_name || 'Module'}</Text>
          <Text style={styles.headerSubtitle}>{user?.name}</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <MaterialIcons name="logout" size={24} color="#E53935" />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Progress Card */}
        <View style={styles.progressCard}>
          <Text style={styles.sectionTitle}>Task Progress</Text>
          <View style={styles.progressContent}>
            <CircularProgress
              size={120}
              width={12}
              fill={progress?.progress || 0}
              tintColor="#4A90E2"
              backgroundColor="#E0E0E0"
            >
              {() => (
                <View style={styles.progressInner}>
                  <Text style={styles.progressValue}>{Math.round(progress?.progress || 0)}%</Text>
                  <Text style={styles.progressLabel}>Complete</Text>
                </View>
              )}
            </CircularProgress>
            <View style={styles.progressStats}>
              <View style={styles.statRow}>
                <MaterialIcons name="checklist" size={24} color="#66BB6A" />
                <Text style={styles.statText}>
                  {progress?.completed_tasks || 0} of {progress?.total_tasks || 0} tasks done
                </Text>
              </View>
              {progress?.all_completed && (
                <View style={styles.completedBadge}>
                  <MaterialIcons name="check-circle" size={20} color="#66BB6A" />
                  <Text style={styles.completedText}>All tasks completed!</Text>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionsGrid}>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => router.push('/(app)/module/tasks')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#E3F2FD' }]}>
              <MaterialIcons name="checklist" size={32} color="#4A90E2" />
            </View>
            <Text style={styles.actionTitle}>Manage Tasks</Text>
            <Text style={styles.actionSubtitle}>
              {progress?.total_tasks || 0} tasks
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => router.push('/(app)/module/handoffs')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#FFF3E0' }]}>
              <MaterialIcons name="swap-horiz" size={32} color="#FFA726" />
              {pendingHandoffs > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{pendingHandoffs}</Text>
                </View>
              )}
            </View>
            <Text style={styles.actionTitle}>Handoffs</Text>
            <Text style={styles.actionSubtitle}>
              {pendingHandoffs} pending
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => router.push('/(app)/module/files')}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#F3E5F5' }]}>
              <MaterialIcons name="folder" size={32} color="#AB47BC" />
            </View>
            <Text style={styles.actionTitle}>Files</Text>
            <Text style={styles.actionSubtitle}>Shared workspace</Text>
          </TouchableOpacity>
        </View>

        {/* Info Card */}
        <View style={styles.infoCard}>
          <MaterialIcons name="info" size={20} color="#4A90E2" />
          <Text style={styles.infoText}>
            Complete all tasks before creating a handoff to another module
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  logoutButton: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  progressCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  progressContent: {
    alignItems: 'center',
  },
  progressInner: {
    alignItems: 'center',
  },
  progressValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
  },
  progressLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  progressStats: {
    marginTop: 24,
    width: '100%',
  },
  statRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statText: {
    fontSize: 16,
    color: '#666',
    marginLeft: 8,
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
    padding: 8,
    backgroundColor: '#E8F5E9',
    borderRadius: 8,
  },
  completedText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#66BB6A',
    marginLeft: 8,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  actionCard: {
    width: '48%',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  actionIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#E53935',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FFF',
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  actionSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: '#E3F2FD',
    borderRadius: 8,
    padding: 12,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    color: '#1976D2',
    marginLeft: 12,
  },
});
