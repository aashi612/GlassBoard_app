import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Image,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { useAuthStore } from '../../../src/store/authStore';
import { handoffsAPI, Handoff } from '../../../src/api/handoffs';
import { modulesAPI, Module } from '../../../src/api/modules';
import { tasksAPI } from '../../../src/api/tasks';
import { format } from 'date-fns';

export default function ModuleHandoffsScreen() {
  const { user } = useAuthStore();
  const [sentHandoffs, setSentHandoffs] = useState<Handoff[]>([]);
  const [receivedHandoffs, setReceivedHandoffs] = useState<Handoff[]>([]);
  const [modules, setModules] = useState<Module[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [createModalVisible, setCreateModalVisible] = useState(false);
  const [viewModalVisible, setViewModalVisible] = useState(false);
  const [selectedHandoff, setSelectedHandoff] = useState<Handoff | null>(null);
  const [activeTab, setActiveTab] = useState<'sent' | 'received'>('received');
  const [formData, setFormData] = useState({
    to_module_id: '',
    proof_text: '',
    proof_document_base64: '',
    proof_document_name: '',
    proof_document_type: '',
  });

  const fetchData = async () => {
    if (!user?.module_id) return;

    try {
      const [sent, received, modulesData, progress] = await Promise.all([
        handoffsAPI.getSent(user.module_id),
        handoffsAPI.getReceived(user.module_id),
        modulesAPI.getAll(),
        tasksAPI.getProgress(user.module_id),
      ]);

      setSentHandoffs(sent);
      setReceivedHandoffs(received);
      setModules(modulesData.filter((m) => m.id !== user.module_id));
    } catch (error) {
      console.error('Failed to fetch handoffs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchData();
  }, [user]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please grant photo library access');
      return;
    }

    const result = await ImagePicker.launchImagePickerAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.5,
      base64: true,
    });

    if (!result.canceled && result.assets[0].base64) {
      const asset = result.assets[0];
      const fileName = asset.uri.split('/').pop() || 'image.jpg';
      setFormData({
        ...formData,
        proof_document_base64: `data:image/jpeg;base64,${asset.base64}`,
        proof_document_name: fileName,
        proof_document_type: 'image/jpeg',
      });
    }
  };

  const handleCreateHandoff = async () => {
    if (!formData.to_module_id || !formData.proof_text.trim()) {
      Alert.alert('Error', 'Please select a module and provide proof text');
      return;
    }

    if (!user?.module_id) return;

    try {
      await handoffsAPI.create({
        from_module_id: user.module_id,
        to_module_id: formData.to_module_id,
        proof_text: formData.proof_text,
        proof_document_base64: formData.proof_document_base64 || undefined,
        proof_document_name: formData.proof_document_name || undefined,
        proof_document_type: formData.proof_document_type || undefined,
      });

      Alert.alert('Success', 'Handoff created successfully');
      setFormData({
        to_module_id: '',
        proof_text: '',
        proof_document_base64: '',
        proof_document_name: '',
        proof_document_type: '',
      });
      setCreateModalVisible(false);
      fetchData();
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to create handoff');
    }
  };

  const handleAccept = async (handoff: Handoff) => {
    try {
      await handoffsAPI.accept(handoff.id);
      Alert.alert('Success', 'Handoff accepted');
      setViewModalVisible(false);
      fetchData();
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to accept handoff');
    }
  };

  const handleReject = (handoff: Handoff) => {
    Alert.prompt(
      'Reject Handoff',
      'Please provide a reason for rejection:',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          style: 'destructive',
          onPress: async (reason) => {
            if (!reason?.trim()) {
              Alert.alert('Error', 'Rejection reason is required');
              return;
            }
            try {
              await handoffsAPI.reject(handoff.id, reason);
              Alert.alert('Success', 'Handoff rejected');
              setViewModalVisible(false);
              fetchData();
            } catch (error: any) {
              Alert.alert('Error', 'Failed to reject handoff');
            }
          },
        },
      ],
      'plain-text'
    );
  };

  const renderHandoff = (handoff: Handoff) => {
    const isPending = handoff.status === 'pending';
    const isAccepted = handoff.status === 'accepted';
    const statusColor = isPending ? '#FFA726' : isAccepted ? '#66BB6A' : '#E53935';

    return (
      <TouchableOpacity
        key={handoff.id}
        style={styles.handoffCard}
        onPress={() => {
          setSelectedHandoff(handoff);
          setViewModalVisible(true);
        }}
      >
        <View style={styles.handoffHeader}>
          <View style={styles.moduleFlow}>
            <Text style={styles.moduleName}>{handoff.from_module_name}</Text>
            <MaterialIcons name="arrow-forward" size={16} color="#666" />
            <Text style={styles.moduleName}>{handoff.to_module_name}</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
            <Text style={styles.statusText}>{handoff.status.toUpperCase()}</Text>
          </View>
        </View>
        <Text style={styles.proofText} numberOfLines={2}>
          {handoff.proof_text}
        </Text>
        <Text style={styles.timestamp}>
          {format(new Date(handoff.submitted_at), 'MMM d, HH:mm')}
        </Text>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'received' && styles.tabActive]}
          onPress={() => setActiveTab('received')}
        >
          <Text style={[styles.tabText, activeTab === 'received' && styles.tabTextActive]}>
            Received
          </Text>
          {receivedHandoffs.filter(h => h.status === 'pending').length > 0 && (
            <View style={styles.tabBadge}>
              <Text style={styles.tabBadgeText}>
                {receivedHandoffs.filter(h => h.status === 'pending').length}
              </Text>
            </View>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'sent' && styles.tabActive]}
          onPress={() => setActiveTab('sent')}
        >
          <Text style={[styles.tabText, activeTab === 'sent' && styles.tabTextActive]}>
            Sent
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {activeTab === 'received'
          ? receivedHandoffs.map(renderHandoff)
          : sentHandoffs.map(renderHandoff)}

        {((activeTab === 'received' && receivedHandoffs.length === 0) ||
          (activeTab === 'sent' && sentHandoffs.length === 0)) && (
          <View style={styles.emptyState}>
            <MaterialIcons name="swap-horiz" size={64} color="#CCC" />
            <Text style={styles.emptyText}>No {activeTab} handoffs</Text>
          </View>
        )}
      </ScrollView>

      <TouchableOpacity
        style={styles.fab}
        onPress={() => setCreateModalVisible(true)}
      >
        <MaterialIcons name="add" size={28} color="#FFF" />
      </TouchableOpacity>

      {/* Create Handoff Modal */}
      <Modal
        visible={createModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setCreateModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <ScrollView contentContainerStyle={styles.modalScrollContent}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Create Handoff</Text>

              <Text style={styles.label}>Select Target Module</Text>
              {modules.map((module) => (
                <TouchableOpacity
                  key={module.id}
                  style={[
                    styles.moduleOption,
                    formData.to_module_id === module.id && styles.moduleOptionSelected,
                  ]}
                  onPress={() => setFormData({ ...formData, to_module_id: module.id })}
                >
                  <View style={[styles.colorDot, { backgroundColor: module.color }]} />
                  <Text style={styles.moduleOptionText}>{module.name}</Text>
                  {formData.to_module_id === module.id && (
                    <MaterialIcons name="check" size={20} color="#4A90E2" />
                  )}
                </TouchableOpacity>
              ))}

              <Text style={styles.label}>Proof / Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Describe what you're handing off..."
                value={formData.proof_text}
                onChangeText={(text) => setFormData({ ...formData, proof_text: text })}
                multiline
                numberOfLines={4}
              />

              <TouchableOpacity style={styles.attachButton} onPress={pickImage}>
                <MaterialIcons name="attach-file" size={20} color="#4A90E2" />
                <Text style={styles.attachButtonText}>
                  {formData.proof_document_name || 'Attach Image (Optional)'}
                </Text>
              </TouchableOpacity>

              {formData.proof_document_base64 && (
                <Image
                  source={{ uri: formData.proof_document_base64 }}
                  style={styles.attachedImage}
                />
              )}

              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={() => {
                    setFormData({
                      to_module_id: '',
                      proof_text: '',
                      proof_document_base64: '',
                      proof_document_name: '',
                      proof_document_type: '',
                    });
                    setCreateModalVisible(false);
                  }}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.saveButton]}
                  onPress={handleCreateHandoff}
                >
                  <Text style={styles.saveButtonText}>Create</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>

      {/* View Handoff Modal */}
      {selectedHandoff && (
        <Modal
          visible={viewModalVisible}
          animationType="slide"
          transparent
          onRequestClose={() => setViewModalVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <ScrollView contentContainerStyle={styles.modalScrollContent}>
              <View style={styles.modalContent}>
                <Text style={styles.modalTitle}>Handoff Details</Text>

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>From:</Text>
                  <Text style={styles.detailValue}>{selectedHandoff.from_module_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>To:</Text>
                  <Text style={styles.detailValue}>{selectedHandoff.to_module_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Status:</Text>
                  <Text
                    style={[
                      styles.detailValue,
                      {
                        color:
                          selectedHandoff.status === 'accepted'
                            ? '#66BB6A'
                            : selectedHandoff.status === 'rejected'
                            ? '#E53935'
                            : '#FFA726',
                      },
                    ]}
                  >
                    {selectedHandoff.status.toUpperCase()}
                  </Text>
                </View>

                <Text style={styles.label}>Proof:</Text>
                <Text style={styles.proofFullText}>{selectedHandoff.proof_text}</Text>

                {selectedHandoff.proof_document_base64 && (
                  <>
                    <Text style={styles.label}>Attached Document:</Text>
                    {selectedHandoff.proof_document_type?.includes('image') ? (
                      <Image
                        source={{ uri: selectedHandoff.proof_document_base64 }}
                        style={styles.attachedImage}
                      />
                    ) : (
                      <Text style={styles.documentName}>{selectedHandoff.proof_document_name}</Text>
                    )}
                  </>
                )}

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Submitted:</Text>
                  <Text style={styles.detailValue}>
                    {format(new Date(selectedHandoff.submitted_at), 'MMM d, yyyy HH:mm')}
                  </Text>
                </View>

                {selectedHandoff.responded_at && (
                  <>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Responded:</Text>
                      <Text style={styles.detailValue}>
                        {format(new Date(selectedHandoff.responded_at), 'MMM d, yyyy HH:mm')}
                      </Text>
                    </View>
                    {selectedHandoff.response_text && (
                      <>
                        <Text style={styles.label}>Response:</Text>
                        <Text style={styles.responseText}>{selectedHandoff.response_text}</Text>
                      </>
                    )}
                  </>
                )}

                <View style={styles.modalActions}>
                  {selectedHandoff.status === 'pending' &&
                    activeTab === 'received' && (
                      <>
                        <TouchableOpacity
                          style={[styles.modalButton, styles.rejectButton]}
                          onPress={() => handleReject(selectedHandoff)}
                        >
                          <Text style={styles.rejectButtonText}>Reject</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[styles.modalButton, styles.acceptButton]}
                          onPress={() => handleAccept(selectedHandoff)}
                        >
                          <Text style={styles.acceptButtonText}>Accept</Text>
                        </TouchableOpacity>
                      </>
                    )}
                  {(selectedHandoff.status !== 'pending' || activeTab === 'sent') && (
                    <TouchableOpacity
                      style={[styles.modalButton, styles.closeButton]}
                      onPress={() => setViewModalVisible(false)}
                    >
                      <Text style={styles.closeButtonText}>Close</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </ScrollView>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabActive: {
    borderBottomColor: '#4A90E2',
  },
  tabText: {
    fontSize: 16,
    color: '#999',
    fontWeight: '600',
  },
  tabTextActive: {
    color: '#4A90E2',
  },
  tabBadge: {
    backgroundColor: '#E53935',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
    paddingHorizontal: 6,
  },
  tabBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FFF',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 16,
  },
  handoffCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  handoffHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  moduleFlow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 8,
  },
  moduleName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#FFF',
  },
  proofText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  timestamp: {
    fontSize: 12,
    color: '#999',
  },
  fab: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#4A90E2',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalScrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 24,
    maxWidth: 500,
    alignSelf: 'center',
    width: '100%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginBottom: 8,
    marginTop: 8,
  },
  moduleOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    marginBottom: 8,
  },
  moduleOptionSelected: {
    borderColor: '#4A90E2',
    backgroundColor: '#E3F2FD',
  },
  colorDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  moduleOptionText: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  attachButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: '#4A90E2',
    borderRadius: 8,
    marginBottom: 16,
  },
  attachButtonText: {
    fontSize: 14,
    color: '#4A90E2',
    marginLeft: 8,
  },
  attachedImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 16,
    resizeMode: 'contain',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  modalButton: {
    flex: 1,
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  cancelButton: {
    backgroundColor: '#F5F5F5',
  },
  saveButton: {
    backgroundColor: '#4A90E2',
  },
  acceptButton: {
    backgroundColor: '#66BB6A',
  },
  rejectButton: {
    backgroundColor: '#E53935',
  },
  closeButton: {
    backgroundColor: '#4A90E2',
  },
  cancelButtonText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  acceptButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  rejectButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  closeButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  detailValue: {
    fontSize: 14,
    color: '#333',
  },
  proofFullText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 16,
    padding: 12,
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
  },
  documentName: {
    fontSize: 14,
    color: '#4A90E2',
    marginBottom: 16,
  },
  responseText: {
    fontSize: 14,
    color: '#666',
    fontStyle: 'italic',
    padding: 12,
    backgroundColor: '#FFF9C4',
    borderRadius: 8,
    marginBottom: 16,
  },
});
